from edu.rosehulman.brahma.plugin.python import PythonPlugin
from edu.rosehulman.brahma.events import CustomEvent
import java.awt.Color as Color



class BallControl(PythonPlugin):
	def __init__(self):
		PythonPlugin.__init__(self, "Python Ball Control")

	def onEnable(self):
		event = CustomEvent("ballcontrol.CHANGE_BALL_COLOR")
		event.addInfo("color", Color.PINK)
		self.getPluginManager().callEvent(event)